Keep the section that relates to your issue!

## Bug Report

### Expected Behaviour
- 

### Actual Behaviour
- 

### Steps to reproduce the behaviour
- 

--------------------------------------------------

## Task Spec

### Needed work
[ - Create [component/page/directive] in order to ... ]
[ - Implmenet [function/class/service] with the purpose of ...]

--------------------------------------------------

## Code Refactoring

### Sections needing refactoring

### Reason for refactoring
